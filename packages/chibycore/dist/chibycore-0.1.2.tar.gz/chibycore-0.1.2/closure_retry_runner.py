"""Phase 3：执行 → 缓存镜像 → 成败判定（exit / LLM / 两者）→ 成功归档；失败则 LLM 修复 + 网关 + 重试（≤3 轮）。"""
from __future__ import annotations

import re
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

from chibycore.closure_llm_fix import filter_fix_commands_for_shell
from chibycore.closure_llm_judge import llm_judge_closure_outcome
from chibycore.closure_service import (
    RetryBudget,
    build_closure_payload,
    success_for_closure,
)
from chibycore.execution_gateway import GatewayAllowResult, gateway_allow_detail
from chibycore.executor_contract import ClosurePayload, ExecResult
from chibycore.kb_closure_archive import archive_closure_success

# 只读探测：有合法诊断输出即可，勿因 systemctl status 退出码 3（未运行）触发自愈
_DIAGNOSTIC_CMD_RE = re.compile(
    r"(?i)^\s*(?:sudo\s+)?"
    r"(?:"
    r"systemctl\s+(?:status|is-active|is-enabled|is-failed|show|list-units|"
    r"list-unit-files|cat)\b|"
    r"(?:df|free|uptime|hostname|uname|whoami|nproc|swapon)\b|"
    r"(?:ps|ss|ip|ifconfig)\s|"
    r"Get-(?:Service|Process|PSDrive|CimInstance|ComputerInfo|NetIPAddress|Volume)\b"
    r")",
)

_TOKEN_RE = re.compile(r"[A-Za-z][A-Za-z0-9_.-]{2,}")
_TOKEN_NOISE = frozenset(
    {
        "sudo", "the", "and", "not", "for", "path", "force", "error", "action",
        "item", "file", "does", "exist", "nothing", "remove", "write", "output",
        "test", "else", "then", "true", "false", "null", "with", "from", "this",
        "that", "have", "been", "will", "command", "status",
    }
)

# 知识库检索（懒加载，避免 sqalchemy 在模块级别加载）
_KB_SEARCH: Optional["KnowledgeHubSearch"] = None  # noqa: F821

def _get_kb_search():
    global _KB_SEARCH
    if _KB_SEARCH is None:
        from chibycore.knowledge_hub.search import KnowledgeHubSearch
        from chibycore.knowledge_hub.models import SearchQuery
        _KB_SEARCH = KnowledgeHubSearch()
    return _KB_SEARCH


# 兼容旧回调 Tuple[bool, str]；推荐返回 GatewayAllowResult
GatewayAllowFn = Callable[[str], Union[GatewayAllowResult, Tuple[bool, str]]]
ExecuteFn = Callable[[str], ExecResult]
FixCommandsFn = Callable[[List[ClosurePayload]], List[str]]
OnSuccessFn = Callable[[ClosurePayload], None]
AfterExecuteFn = Callable[[ClosurePayload], None]
AfterStepFn = Callable[["ClosureStepRecord"], None]
JudgeFn = Callable[[ClosurePayload], Tuple[bool, str]]


def _coerce_gateway_allow(raw: Any) -> GatewayAllowResult:
    """将 gateway_allow 回调结果统一为 GatewayAllowResult。"""
    if isinstance(raw, GatewayAllowResult):
        return raw
    if isinstance(raw, tuple) and len(raw) >= 2:
        return GatewayAllowResult(
            allowed=bool(raw[0]),
            reason=str(raw[1] or ""),
            pending_change_control=bool(raw[2]) if len(raw) > 2 else False,
            pending_id=str(raw[3] or "") if len(raw) > 3 else "",
        )
    # ExecutionOutcome 或带同名字段的对象
    if hasattr(raw, "allowed"):
        return GatewayAllowResult(
            allowed=bool(raw.allowed),
            reason=str(getattr(raw, "reason", "") or ""),
            pending_change_control=bool(
                getattr(raw, "pending_change_control", False)
            ),
            pending_id=str(getattr(raw, "pending_id", "") or ""),
            denial_category=str(getattr(raw, "denial_category", "") or ""),
            rule_kind=str(getattr(raw, "rule_kind", "") or ""),
            matched_pattern=str(getattr(raw, "matched_pattern", "") or ""),
            override_requires_approval=bool(
                getattr(raw, "override_requires_approval", False)
            ),
            progressive_policy_hint=str(
                getattr(raw, "progressive_policy_hint", "") or ""
            ),
        )
    raise TypeError(
        f"gateway_allow 应返回 GatewayAllowResult 或 (allowed, reason[, ...])，得到 {type(raw)!r}"
    )


def _step_from_gateway(
    *,
    phase: str,
    command: str,
    g: GatewayAllowResult,
    fix_round: int = 0,
    result: Optional[ExecResult] = None,
    payload: Optional[ClosurePayload] = None,
) -> ClosureStepRecord:
    return ClosureStepRecord(
        phase=phase,
        command=command,
        gateway_allowed=bool(g.allowed),
        gateway_reason=(g.reason or "") if not g.allowed else "",
        result=result,
        payload=payload,
        fix_round=fix_round,
        pending_change_control=bool(g.pending_change_control),
        change_control_pending_id=(g.pending_id or "") if g.pending_change_control else "",
        gateway_detail=gateway_allow_detail(g),
    )


@dataclass
class ClosureStepRecord:
    phase: str  # initial | fix
    command: str
    gateway_allowed: bool
    gateway_reason: str
    result: Optional[ExecResult] = None
    payload: Optional[ClosurePayload] = None
    fix_round: int = 0
    exit_ok: Optional[bool] = None
    llm_judge_ok: Optional[bool] = None
    llm_judge_reason: str = ""
    outcome_detail: str = ""
    #: 命中变更冻结窗口（待审批，非策略拒绝）
    pending_change_control: bool = False
    change_control_pending_id: str = ""
    #: 网关拒绝时可解释性载荷（denial_category / rule_kind 等）
    gateway_detail: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ClosureRunResult:
    ok: bool
    final_payload: Optional[ClosurePayload]
    steps: List[ClosureStepRecord] = field(default_factory=list)
    stop_reason: str = ""
    # 本轮实际用过的修复来源（knowledge_hub / remediator / llm / heuristic / custom）
    fix_sources: List[str] = field(default_factory=list)


def evaluate_closure_success_detailed(
    cp: ClosurePayload,
    *,
    success_mode: str,
    success_exit_codes: Optional[List[int]],
    llm_judge_fn: Optional[JudgeFn] = None,
) -> Tuple[bool, str, bool, Optional[bool], str]:
    """
    返回：(综合是否成功, detail 文本, exit_ok, llm_judge_ok|None, llm_judge_reason)。
    llm_judge_ok 为 None 表示本轮未咨询 LLM（exit_code 模式）。
    """
    mode = (success_mode or "exit_code").strip().lower()
    exit_ok = success_for_closure(cp, success_exit_codes)
    fn = llm_judge_fn or llm_judge_closure_outcome

    from chibycore.closure_labels import format_both_mode_detail, humanize_judge_reason

    if mode == "exit_code":
        detail = "退出码通过" if exit_ok else "退出码未通过"
        return exit_ok, detail, exit_ok, None, ""

    lj, reason = fn(cp)
    lr = (reason or "")[:800]

    if mode == "llm":
        rsn = (reason or "").strip() or ("智能判定通过" if lj else "智能判定未通过")
        return lj, rsn, exit_ok, lj, lr

    if mode == "both":
        combined = bool(exit_ok and lj)
        detail = format_both_mode_detail(exit_ok=exit_ok, llm_ok=lj, reason=reason)
        return combined, detail, exit_ok, lj, lr

    ok = exit_ok
    return ok, humanize_judge_reason("unknown_mode_fallback_exit_code"), exit_ok, None, ""


def evaluate_closure_success(
    cp: ClosurePayload,
    *,
    success_mode: str,
    success_exit_codes: Optional[List[int]],
    llm_judge_fn: Optional[JudgeFn] = None,
) -> Tuple[bool, str]:
    """
    success_mode:
      - exit_code：仅 exit_code ∈ success_exit_codes（默认 [0]）
      - llm：仅 LLM 判定（不可用时回退 exit_code）
      - both：exit 通过 且 LLM 判定成功
    """
    ok, detail, _, _, _ = evaluate_closure_success_detailed(
        cp,
        success_mode=success_mode,
        success_exit_codes=success_exit_codes,
        llm_judge_fn=llm_judge_fn,
    )
    return ok, detail


def is_readonly_diagnostic_command(command: str) -> bool:
    """只读状态/资源探测：不应因非零退出码（如 systemctl status=3）进入自愈。"""
    return bool(_DIAGNOSTIC_CMD_RE.match((command or "").strip()))


def _significant_tokens(text: str) -> set:
    return {
        t.lower()
        for t in _TOKEN_RE.findall(text or "")
        if t.lower() not in _TOKEN_NOISE
    }


def kb_fix_relevant_to_command(original_cmd: str, fix_cmd: str) -> bool:
    """知识库修复须与失败命令有词面重叠，避免把删 a.dat 套到 nginx status。"""
    o = _significant_tokens(original_cmd)
    if not o:
        return True
    f = _significant_tokens(fix_cmd)
    return bool(o & f)


def diagnostic_closure_ok(command: str, cp: ClosurePayload) -> bool:
    """只读探测拿到可解读结果即视为闭环成功（含 unit inactive / not-found）。"""
    if not is_readonly_diagnostic_command(command):
        return False
    try:
        code = int(cp.exit_code)
    except (TypeError, ValueError):
        return False
    blob = f"{cp.stdout or ''}{cp.stderr or ''}"
    if re.search(r"(?i)syntax error|unexpected token", blob):
        return False
    # systemctl：0–4 均为合法诊断；其它只读：有输出且非壳语法错即可
    if re.search(r"(?i)\bsystemctl\b", command or ""):
        return 0 <= code <= 4
    if re.search(r"(?i)\bGet-Service\b|\bGet-Process\b", command or ""):
        return code == 0 or bool(blob.strip())
    return code == 0 or bool(blob.strip())


def _lookup_kb_fixes(
    history: List[ClosurePayload],
    *,
    shell_profile: str = "unix",
    distro_family: Optional[str] = None,
    pkg_manager: Optional[str] = None,
) -> Optional[List[str]]:
    """查询 KnowledgeHub，若存在高匹配度的历史修复则直接返回，否则返回 None 让调用方退回到 LLM。"""
    if not history:
        return None

    # 从第一条 payload 提取命令 + 错误信息
    first = history[0]
    cmd = first.effective_command or first.raw_command or ""
    stderr = (first.stderr or "")[:1000]
    stdout = (first.stdout or "")[:1000]
    query_text = f"{cmd} {stderr} {stdout}".strip()[:500]
    if not query_text:
        return None

    try:
        from chibycore.knowledge_hub.models import SearchQuery

        searcher = _get_kb_search()
        sq = SearchQuery(
            q=query_text,
            mode="kb",
            limit=3,
        )
        resp = searcher.search(sq)
        if not resp.results:
            return None

        # 只取高置信度（score >= 0.3）且是修复类结果
        fixes: List[str] = []
        for r in resp.results:
            if r.score >= 0.3:
                # 从 result title/snippet 无法直接拿到 remediation 命令，
                # 需要通过 entry_id 回查 storage
                try:
                    storage = searcher._storage
                    entry = storage.get_kb_entry(r.entry_id)
                    if entry and entry.remediation and entry.remediation.strip():
                        fixes.append(entry.remediation.strip())
                except Exception:
                    continue

        if not fixes:
            return None

        # 壳/发行版过滤 + 与原命令相关性（防串台）
        fixes = filter_fix_commands_for_shell(
            fixes,
            shell_profile,
            distro_family=distro_family,
            pkg_manager=pkg_manager,
        )
        fixes = [f for f in fixes if kb_fix_relevant_to_command(cmd, f)]
        if fixes:
            logger = __import__("logging").getLogger(__name__)
            logger.info(
                "知识库命中 %d 条可用修复方案: %s",
                len(fixes), [f[:60] for f in fixes],
            )
            return fixes
        logger = __import__("logging").getLogger(__name__)
        logger.info(
            "知识库命中已丢弃（壳不符或与原命令无关）cmd=%s",
            (cmd or "")[:80],
        )
    except Exception as ex:
        logger = __import__("logging").getLogger(__name__)
        logger.warning("知识库查询失败（非致命，退回到 LLM）: %s", ex)

    return None


def run_closure_retry_loop(
    *,
    trace_id: str,
    initial_command: str,
    execute: ExecuteFn,
    gateway_allow: GatewayAllowFn,
    shell_profile: str = "unix",
    distro_family: Optional[str] = None,
    pkg_manager: Optional[str] = None,
    nl_intent_hint: Optional[str] = None,
    session_id: Optional[str] = None,
    plan_id: Optional[str] = None,
    max_fix_attempts: int = 3,
    success_exit_codes: Optional[List[int]] = None,
    success_mode: str = "exit_code",
    llm_judge_fn: Optional[JudgeFn] = None,
    llm_fix_commands: Optional[FixCommandsFn] = None,
    on_success: Optional[OnSuccessFn] = None,
    archive_kb: bool = False,
    on_after_execute: Optional[AfterExecuteFn] = None,
    on_after_step: Optional[AfterStepFn] = None,
    cancel_check: Optional[Callable[[], bool]] = None,
) -> ClosureRunResult:
    """
    1) 初始命令先过网关，再 execute → ClosurePayload
    2) on_after_step：每步写入外部（推荐；含网关拒绝与 fix_round）；若未提供则用 on_after_execute(payload)
    3) evaluate_closure_success → 成功则 archive_kb + on_success
    4) 否则最多 max_fix_attempts 轮 LLM 修复（每轮可尝试多条过网关命令）
    """
    steps: List[ClosureStepRecord] = []
    history: List[ClosurePayload] = []

    def _cancelled() -> bool:
        return bool(cancel_check and cancel_check())

    def _tid(suffix: str = "") -> str:
        return trace_id + suffix

    def _emit_after_step(rec: ClosureStepRecord) -> None:
        if on_after_step:
            on_after_step(rec)
        elif on_after_execute and rec.payload:
            on_after_execute(rec.payload)

    def _fire_success(cp: ClosurePayload, judge_detail: str) -> None:
        if archive_kb:
            archive_closure_success(cp, judge_reason=judge_detail, trace_id=trace_id)
        if on_success:
            on_success(cp)

    g0 = _coerce_gateway_allow(gateway_allow(initial_command.strip()))
    if not g0.allowed:
        steps.append(
            _step_from_gateway(
                phase="initial",
                command=initial_command,
                g=g0,
                fix_round=0,
            )
        )
        if not steps[-1].gateway_reason:
            steps[-1].gateway_reason = "gateway_denied"
        _emit_after_step(steps[-1])
        stop = (
            "initial_change_control_hold"
            if g0.pending_change_control
            else "initial_gateway_denied"
        )
        return ClosureRunResult(
            ok=False,
            final_payload=None,
            steps=steps,
            stop_reason=stop,
        )

    if _cancelled():
        return ClosureRunResult(
            ok=False,
            final_payload=None,
            steps=steps,
            stop_reason="user_cancelled",
        )

    res0 = execute(initial_command)
    cp0 = build_closure_payload(
        trace_id=_tid(""),
        raw_command=initial_command,
        effective_command=initial_command,
        result=res0,
        nl_intent_hint=nl_intent_hint,
        session_id=session_id,
        plan_id=plan_id,
    )
    history.append(cp0)
    steps.append(
        _step_from_gateway(
            phase="initial",
            command=initial_command,
            g=g0,
            fix_round=0,
            result=res0,
            payload=cp0,
        )
    )
    ok0, detail0, ex0, lj0, lr0 = evaluate_closure_success_detailed(
        cp0,
        success_mode=success_mode,
        success_exit_codes=success_exit_codes,
        llm_judge_fn=llm_judge_fn,
    )
    if (not ok0) and diagnostic_closure_ok(initial_command, cp0):
        ok0 = True
        detail0 = "diagnostic_ok"
        ex0 = True
    rec0 = steps[-1]
    rec0.exit_ok = ex0
    rec0.llm_judge_ok = lj0
    rec0.llm_judge_reason = lr0
    rec0.outcome_detail = detail0
    _emit_after_step(rec0)
    if ok0:
        _fire_success(cp0, detail0)
        return ClosureRunResult(True, cp0, steps, "success_initial")

    # 只读探测失败也不进自愈（避免知识库/LLM 串台改写查询）
    if is_readonly_diagnostic_command(initial_command):
        return ClosureRunResult(
            False, cp0, steps, "diagnostic_no_heal",
        )

    budget = RetryBudget(max_attempts=max(0, int(max_fix_attempts)))
    fix_sources: List[str] = []

    def _pick_fixes() -> List[str]:
        # 1) 先查知识库（如果有自定义 llm_fix_commands 则跳过，由外部控制）
        if not llm_fix_commands:
            kb_fixes = _lookup_kb_fixes(
                history,
                shell_profile=shell_profile,
                distro_family=distro_family,
                pkg_manager=pkg_manager,
            )
            if kb_fixes:
                fix_sources.append("knowledge_hub")
                return kb_fixes
        # 2) 自定义修复函数
        if llm_fix_commands:
            fix_sources.append("custom")
            return filter_fix_commands_for_shell(
                llm_fix_commands(history) or [],
                shell_profile,
                distro_family=distro_family,
                pkg_manager=pkg_manager,
            )
        # 3) 默认 LLM / remediator 修复流水线
        from chibycore.closure_llm_fix import call_fix_pipeline_with_source

        fixes, src = call_fix_pipeline_with_source(
            history,
            shell_profile=shell_profile,
            distro_family=distro_family,
            pkg_manager=pkg_manager,
        )
        if fixes and src and src != "none":
            fix_sources.append(src)
        return fixes

    def _result(
        ok: bool,
        payload: Optional[ClosurePayload],
        reason: str,
    ) -> ClosureRunResult:
        # 去重保序
        seen_src: List[str] = []
        for s in fix_sources:
            if s and s not in seen_src:
                seen_src.append(s)
        return ClosureRunResult(
            ok=ok,
            final_payload=payload,
            steps=steps,
            stop_reason=reason,
            fix_sources=seen_src,
        )

    fix_round_counter = 0
    while budget.can_retry():
        if _cancelled():
            return _result(False, history[-1] if history else None, "user_cancelled")
        budget.consume()
        fix_round_counter += 1
        if _cancelled():
            return _result(False, history[-1] if history else None, "user_cancelled")
        fixes = _pick_fixes()
        # 跳过历史已执行过的候选，避免同一条 PowerShell/错误命令空转多轮
        tried = {
            (cp.effective_command or cp.raw_command or "").strip()
            for cp in history
            if (cp.effective_command or cp.raw_command or "").strip()
        }
        fixes = [c for c in (fixes or []) if (c or "").strip() and (c or "").strip() not in tried]
        if not fixes:
            return _result(False, history[-1], "no_fix_commands")
        any_allowed_exec = False
        for cmd in fixes:
            if _cancelled():
                return _result(False, history[-1] if history else None, "user_cancelled")
            gf = _coerce_gateway_allow(gateway_allow(cmd))
            if not gf.allowed:
                steps.append(
                    _step_from_gateway(
                        phase="fix",
                        command=cmd,
                        g=gf,
                        fix_round=fix_round_counter,
                    )
                )
                if not steps[-1].gateway_reason:
                    steps[-1].gateway_reason = "denied"
                _emit_after_step(steps[-1])
                continue
            any_allowed_exec = True
            if _cancelled():
                return _result(False, history[-1] if history else None, "user_cancelled")
            r = execute(cmd)
            cp = build_closure_payload(
                trace_id=_tid("_fix_" + uuid.uuid4().hex[:8]),
                raw_command=initial_command,
                effective_command=cmd,
                result=r,
                nl_intent_hint=nl_intent_hint,
                session_id=session_id,
                plan_id=plan_id,
            )
            history.append(cp)
            steps.append(
                _step_from_gateway(
                    phase="fix",
                    command=cmd,
                    g=gf,
                    fix_round=fix_round_counter,
                    result=r,
                    payload=cp,
                )
            )
            okc, det, ex_ok, lj_ok, lj_rs = evaluate_closure_success_detailed(
                cp,
                success_mode=success_mode,
                success_exit_codes=success_exit_codes,
                llm_judge_fn=llm_judge_fn,
            )
            rec_f = steps[-1]
            rec_f.exit_ok = ex_ok
            rec_f.llm_judge_ok = lj_ok
            rec_f.llm_judge_reason = lj_rs
            rec_f.outcome_detail = det
            _emit_after_step(rec_f)
            if okc:
                _fire_success(cp, det)
                return _result(True, cp, "success_after_fix")
        if not any_allowed_exec:
            return _result(False, history[-1], "all_fix_suggestions_denied_by_gateway")

    return _result(
        False,
        history[-1] if history else None,
        "max_fix_attempts_exhausted",
    )
